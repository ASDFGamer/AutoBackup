# AutoBackup

<p>Dies ist ein Programm, welches automatische Backups machen kann.
Automatisch bedeutet hier, dass das Programm gestartet wird, ohne Abfrage das Backup startet und sobald alles fertig ist schließt sich das Programm wieder. 
Alle Einstellungen sind in eine Datei ausgelgert welche einfach edietert werden kann.<br>
<br>
Für nächste Updates geplant: Netzwerkunterstützung, verschieben der Einstellungsdatei</p>

<br><b>English</b></br>
<p>This is program which can makes automatic Backups.
Automatic means that the backups starts when the program starts and the program closes after the backup is done.
All settings are in a file that can be easily edited.<br>
<br>
Planed for next updates: Backups over the Network, moving of the settingsfile. </p>
