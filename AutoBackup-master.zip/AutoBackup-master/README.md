# AutoBackup

<p>Dies ist ein Programm, welches automatische Backups machen kann.
Automatisch bedeutet hier, dass das Programm gestartet wird, ohne Abfrage das Backup startet und sobald alles fertig ist schließt sich das Programm wieder. 
Alle Einstellungen sind in eine Datei ausgelgert welche einfach edietert werden kann.<br>
<br>
Für nächste Updates geplant: Netzwerkunterstützung, verschieben der Einstellungsdatei</p>
