
package autobackup.copyFile;

import hilfreich.Convertable;
import static hilfreich.FileUtil.*;
import hilfreich.Log;
import static hilfreich.LogLevel.*;
import java.io.File;
import java.net.URISyntaxException;
import java.nio.file.CopyOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import static java.nio.file.StandardCopyOption.*;
import java.util.LinkedList;
import java.util.Properties;
import java.net.URL;

/**
 *
 * @author Christoph Wildhagen 
 */
public class Lokal implements ISichern{
    
        //----Variablen----
    /**
     * Dies ist der Ordner der gesichert werden soll.
     */
    private URL quellordner;
    
    /**
     * Dies ist der Ordner der gesichert werden soll.
     */
    private Path quellordnerPath;
    
    /**
     * Dies ist der Ordner in den gespeichert werden soll.
     */
    private URL zielordner;
    
    /**
     * Dies ist der Ordner in den gespeichert werden soll.
     */
    private Path zielordnerPath;
    
    /**
     * Dies gibt an wie viele Versionen behalten werden sollen, wenn overwrite ausgeschaltet ist.
     */
    private int versions;
    
    /**
     * Dies sind die Dateien die geändert wurden oder neu sind
     */
    private LinkedList<Path> neueDateien = new LinkedList<>();
    
    /**
     * Der Dateibaum wird geladen als Properties, TODO schauen ob es performanter geht.
     */
    private Properties dateibaum = new Properties();
    
    Log log = new Log(super.getClass().getSimpleName());
    
    public Lokal(URL quellordner,URL zielordner,int versions) throws IllegalArgumentException
    {
        if (!quellordner.getProtocol().equals("file")||!zielordner.getProtocol().equals("file"))//theorethisch nicht nötig, aber für die sicherheit sinnvoll.
        {
            throw new IllegalArgumentException("Es kann kein lokales Backup gemacht werden da der Pfad nicht auf eine Lokale Datei verweist sondern auf " + quellordner.getProtocol()); 
        }
        try
        {
            this.quellordner = quellordner;
            this.quellordnerPath =Paths.get(quellordner.toURI());
            this.zielordner = zielordner;
            this.zielordnerPath =Paths.get(zielordner.toURI());
            this.versions = versions;
        }
        catch (URISyntaxException e)
        {
            throw new IllegalArgumentException("Es kann kein lokales Backup gemacht werden da der Pfad nicht auf eine Lokale Datei verweist"); 
        }
        
    }
    
    /**
     * Diese Funktion sichert die ausgewählten Dateien in den Zielordner und legt falls nötig Versionen an.
     * @return true, falls das Backup geklappt hat, sonst false (für true muss die versionierung nicht geklappt haben).
     */
    @Override
    public boolean backupFiles()
    {
        boolean result = true;
        Path kurzpfad;
        Path zielpfad;
        int quellNameCount = quellordnerPath.getNameCount();
        for (Path datei : neueDateien)
        {
            kurzpfad = datei.subpath(quellNameCount, datei.getNameCount());
            zielpfad = zielordnerPath.resolve(kurzpfad);
            if (isFolder(datei))
            {
                if (!isFolder(zielpfad))
                {
                    createFolder(zielpfad);
                }
            }
            else if (isFile(zielpfad)) //Die Datei hat sich geändert (oder es gab noch keinen Dateibaum)
            {
                log.write("Die Datei " + zielpfad + " existiert schon, hat sich aber geändert.");
                versionierung(zielpfad,1,this.versions);
                boolean result_temp = copyFile(datei, zielpfad, new CopyOption[]{REPLACE_EXISTING, COPY_ATTRIBUTES});
                if(!result_temp)
                {
                    result = false;
                }
            }
            else //Es ist eine Datei die noch nicht kopiert wurde
            {
                log.write("Die Datei " + datei.toString() + " wird gesichert");
                boolean result_temp = copyFile(datei, zielpfad, new CopyOption[]{COPY_ATTRIBUTES});
                if(!result_temp)
                {
                    result = false;
                }
            } 
        }
        return result;
    }
    
    /**
     * Dies vergleicht die Dateien die in der Einstellungsdatei waren mit
     * @param ordner Der übergeordnete Ordner
     * @return Eine liste mit allen geänderten Dateien.
     */
    private LinkedList<Path> vergleicheDateien(Path ordnerpath)
    {
        File ordner = ordnerpath.toFile();
        File[] dateien = ordner.listFiles();
        LinkedList<Path> geaendert = new LinkedList<>();
        String path;
        for (File datei : dateien)
        {
            path = datei.getAbsolutePath();//Könnte Probleme wegen File/Path umwandlung geben.
            if ((!dateibaum.containsKey(path)) || !Convertable.toLong(dateibaum.getProperty(path)))
            {
                geaendert.add(Paths.get(datei.getAbsolutePath()));
            }
            else if (datei.lastModified()>Long.valueOf((String)dateibaum.get(path)))
            {
                geaendert.add(Paths.get(datei.getAbsolutePath()));
            }
            //TODO über Hash gehen, da es Probleme mit der änderungszeit gben könnte.
            /*if (datei.isDirectory())
            {
                geaendert.addAll(vergleicheDateien(datei));
            }*/
        }
        return geaendert;
    }
    
    /**
     * Dies vergleicht eine Datei aus dem Quellordner mit ihrem Equivalent im Zielordner und fügt sie zu den zu sichernden Dateien hinzugefügt.
     * @param datei Die Datei die überprüft werden soll.
     * @return true, falls alles geklappt hat, sonst false.
     */
    private boolean vergleicheDatei(Path datei)
    {
        if (datei == null)
        {
            log.write("",FEHLER);
        }
        Path zielpfad = this.zielordnerPath.resolve(datei.subpath(this.quellordnerPath.getNameCount(), datei.getNameCount())); //Hergeleitet von backupFiles()
        if (zielpfad.toFile().lastModified()<datei.toFile().lastModified())
        {
            this.neueDateien.add(datei);
        }
        return true;
    }
    
    /**
     * Dies überprüft die Dateien im Zielordner, ob sie neuer sind und trägt neue Dateien zum sichern ein
     * @return true, falls alles geklappt hat, sonst false.
     */
    @Override
    public boolean checkBackupFiles()
    {

        if (this.quellordnerPath.toFile().isDirectory())
        {
            File[] dateien = this.quellordnerPath.toFile().listFiles();
            for (File datei : dateien)
            {
                if (datei.isDirectory())
                {
                    checkBackupFilesR(datei);
                }
                else
                {
                    vergleicheDatei(datei.toPath());
                }
            }
        }
        else
        {
            vergleicheDatei(this.quellordnerPath);
        }
        return true;
    }
    
     /**
     * Dies überprüft die Dateien im Zielordner, ob sie neuer sind und trägt neue Dateien zum sichern ein
     * @return true, falls alles geklappt hat, sonst false.
     */
    private boolean checkBackupFilesR(File ordner)
    {
        if (ordner.isDirectory())
        {
            File[] dateien = ordner.listFiles();
            for (File datei : dateien)
            {
                if (datei.isDirectory())
                {
                    checkBackupFilesR(datei);
                }
                else
                {
                    vergleicheDatei(datei.toPath());
                }
            }
        }
        else
        {
            vergleicheDatei(ordner.toPath());
        }
        return true;
    }
    
    /**
     * Dies markiert alle Dateien aus dem Quellordner zum sichern.
     * @return true, falls es geklappt hat, sonst false.
     */
    @Override
    public boolean checkAllFiles()
    {
        if (this.quellordnerPath.toFile().isDirectory())
        {
            File[] dateien = this.quellordnerPath.toFile().listFiles();
            for (File datei : dateien)
            {
                if (datei.isDirectory())
                {
                    checkAllFilesR(datei);
                }
                else
                {
                    this.neueDateien.add(datei.toPath());
                }
            }
        }
        else
        {
            this.neueDateien.add(this.quellordnerPath);
        }
        
        return true;
    }
    
    /**
     * Dies markiert alle Dateien aus dem Quellordner zum sichern.
     * Nur für rekursion
     * @return true, falls es geklappt hat, sonst false.
     */
    private boolean checkAllFilesR(File ordner)
    {
        if (ordner.isDirectory())
        {
            File[] dateien = ordner.listFiles();
            for (File datei : dateien)
            {
                if (datei.isDirectory())
                {
                    checkAllFilesR(datei);
                }
                else
                {
                    this.neueDateien.add(datei.toPath());
                }
            }
        }
        else
        {
            this.neueDateien.add(ordner.toPath());
        }
        
        return true;
    }
    
        
    
    /**
     * Dies listet alle Ordner/Dateien in einem Ordner auf
     * @param ordner der übergeordnete Ordner
     * @return Die Dateistruktur als List
     */
    private LinkedList<String> dateistrukturEinlesen(File ordner)
    {
        LinkedList<String> dateistruktur = new LinkedList<>();
        File[] dateien = ordner.listFiles();
        for (File datei : dateien)
        {
            dateistruktur.add(datei.getAbsolutePath());
            if (datei.isDirectory())
            {
                dateistruktur.addAll(dateistrukturEinlesen(datei));
            }
        }
        return dateistruktur;
    }
    
    @Override
    public boolean setDateibaum(Properties dateibaum)
    {
        this.dateibaum = dateibaum;
        this.neueDateien = vergleicheDateien(this.quellordnerPath); //TODO überprüfen ob sinnvoll
        return true;
    }
    
    @Override
    public LinkedList<Path> getNeueDateien()
    {
        return this.neueDateien;
    }
}
