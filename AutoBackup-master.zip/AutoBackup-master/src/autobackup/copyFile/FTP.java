
package autobackup.copyFile;

import java.net.URL;
import java.nio.file.Path;
import java.util.LinkedList;
import java.util.Properties;
import org.apache.commons.net.ftp.FTPClient;

/**
 *
 * @author Christoph Wildhagen 
 */
public class FTP implements ISichern {
    
    public FTP(URL quellordner,URL zielordner,int versions) throws IllegalArgumentException
    {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public boolean backupFiles()
    {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean checkAllFiles() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean checkBackupFiles() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean setDateibaum(Properties dateibaum) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public LinkedList<Path> getNeueDateien()
    {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
