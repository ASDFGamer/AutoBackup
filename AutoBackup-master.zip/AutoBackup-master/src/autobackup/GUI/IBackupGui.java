package autobackup.GUI;

/**
 * @author Christoph Wildhagen
 */
public interface IBackupGui
{
    /**
     * Dies startet das Backup
     */
    public void startBackup();
}
