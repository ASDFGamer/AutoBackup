
package autobackup.Data;

/**
 *
 * @author Christoph Wildhagen 
 */
public class Const {
    
    static final public String PROGRAMM_NAME = "AutoBackup";
    
    static final public String VERSION = "0.001";
    
    static final public String[] LOGEIGENSCHAFTEN = {"Console + Datei", "Nur Console", "Nur Datei", "Alles Aus"}; //TODO convert to enum
    
    static final public String[] ANZAHLEN = {"UNBEGRENZT", "1", "2","3","4","5","6","7","8","9","10"};
}
